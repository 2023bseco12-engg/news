package com.example

import com.example.data.local.InitialNewsData
import com.example.data.model.NewsCategory
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testInitialSummariesCoverAllFourRequiredCategories() {
    val summaries = InitialNewsData.getInitialSummaries()
    assertTrue(summaries.isNotEmpty())
    
    val categories = summaries.map { it.category }.toSet()
    assertTrue(categories.contains(NewsCategory.ECONOMICS.name))
    assertTrue(categories.contains(NewsCategory.CLIMATE.name))
    assertTrue(categories.contains(NewsCategory.EDUCATION.name))
    assertTrue(categories.contains(NewsCategory.WORLD.name))
    
    // Check that each summary has takeaways and an executive summary
    summaries.forEach { summary ->
      assertTrue(summary.takeaways.isNotEmpty())
      assertTrue(summary.executiveSummary.isNotBlank())
      assertTrue(summary.whyItMatters.isNotBlank())
    }
  }
}


package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class NewsCategory(
    val title: String,
    val subtitle: String
) {
    ALL("All", "Top global briefings"),
    ECONOMICS("Economics", "Markets, inflation, trade & central banks"),
    CLIMATE("Climate", "Renewable energy, decarbonization & policy"),
    EDUCATION("Education", "Higher ed, STEM, literacy & EdTech"),
    WORLD("World News", "Geopolitics, diplomacy & international accords")
}

@Entity(tableName = "news_summaries")
data class NewsSummary(
    @PrimaryKey
    val id: String,
    val title: String,
    val category: String, // ECONOMICS, CLIMATE, EDUCATION, WORLD
    val publishedAt: String,
    val timestamp: Long,
    val readTimeMinutes: Int,
    val keyTakeawaysDelimited: String, // Delimited by "|||"
    val executiveSummary: String,
    val whyItMatters: String,
    val sourceName: String,
    val impactLevel: String, // "High Impact", "Policy Shift", "Breakthrough", "Market Moving", "Developing"
    val isBookmarked: Boolean = false,
    val isRead: Boolean = false,
    val tagsDelimited: String = "" // Delimited by "|||"
) {
    val takeaways: List<String>
        get() = if (keyTakeawaysDelimited.isBlank()) emptyList() else keyTakeawaysDelimited.split("|||")

    val tags: List<String>
        get() = if (tagsDelimited.isBlank()) emptyList() else tagsDelimited.split("|||")

    val newsCategory: NewsCategory
        get() = try {
            NewsCategory.valueOf(category)
        } catch (_: Exception) {
            NewsCategory.ALL
        }
}

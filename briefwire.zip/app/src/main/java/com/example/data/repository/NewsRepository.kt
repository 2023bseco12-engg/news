package com.example.data.repository

import com.example.data.local.InitialNewsData
import com.example.data.local.NewsDao
import com.example.data.model.NewsCategory
import com.example.data.model.NewsSummary
import kotlinx.coroutines.flow.Flow

class NewsRepository(private val newsDao: NewsDao) {

    suspend fun ensureInitialDataLoaded() {
        val count = newsDao.getCount()
        if (count == 0) {
            newsDao.insertAll(InitialNewsData.getInitialSummaries())
        }
    }

    fun getAllSummaries(): Flow<List<NewsSummary>> = newsDao.getAllSummaries()

    fun getSummariesByCategory(category: NewsCategory): Flow<List<NewsSummary>> {
        return if (category == NewsCategory.ALL) {
            newsDao.getAllSummaries()
        } else {
            newsDao.getSummariesByCategory(category.name)
        }
    }

    fun getBookmarkedSummaries(): Flow<List<NewsSummary>> = newsDao.getBookmarkedSummaries()

    fun getSummaryById(id: String): Flow<NewsSummary?> = newsDao.getSummaryById(id)

    fun searchSummaries(query: String): Flow<List<NewsSummary>> = newsDao.searchSummaries(query.trim())

    suspend fun toggleBookmark(id: String, currentStatus: Boolean) {
        newsDao.updateBookmark(id, !currentStatus)
    }

    suspend fun markAsRead(id: String, isRead: Boolean = true) {
        newsDao.updateReadStatus(id, isRead)
    }

    suspend fun markAllAsRead() {
        newsDao.markAllAsRead()
    }

    suspend fun clearReadHistory() {
        newsDao.clearReadHistory()
    }

    suspend fun addNewSummary(summary: NewsSummary) {
        newsDao.insert(summary)
    }
}

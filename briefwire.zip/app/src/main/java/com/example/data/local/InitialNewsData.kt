package com.example.data.local

import com.example.data.model.NewsCategory
import com.example.data.model.NewsSummary

object InitialNewsData {
    fun getInitialSummaries(): List<NewsSummary> = listOf(
        // ECONOMICS
        NewsSummary(
            id = "eco_01",
            title = "Global Central Banks Shift to Neutral Rates as Inflation Reaches 2.1% Baseline",
            category = NewsCategory.ECONOMICS.name,
            publishedAt = "25 mins ago",
            timestamp = System.currentTimeMillis() - (25 * 60 * 1000),
            readTimeMinutes = 1,
            keyTakeawaysDelimited = "Major central banks signal coordinated rate normalization to support business capital expenditure.|||Headline inflation across G10 economies settled to an average of 2.1%, near target bands.|||Bond yields stabilized across 10-year sovereigns, reducing corporate refinancing headwinds.",
            executiveSummary = "In a synchronized policy transition, central banks across North America and Europe have signaled an end to restrictive monetary postures. By moderating baseline interest rates toward neutral territories (estimated between 2.25% and 2.75%), policymakers aim to preserve resilient employment figures without reigniting inflationary pressures.\n\nMarket responses have been broadly constructive. Equity indexes saw broad-based participation beyond mega-cap tech, while private credit originations jumped 14% quarter-over-quarter as lending spreads tightened.",
            whyItMatters = "Lower borrowing costs reduce mortgage rates for consumers and unleash pent-up corporate investments in infrastructure, technology, and hiring.",
            sourceName = "Financial Times & MacroMonitor",
            impactLevel = "Market Moving",
            tagsDelimited = "Central Banks|||Interest Rates|||Inflation|||Macro"
        ),
        NewsSummary(
            id = "eco_02",
            title = "Semiconductor Supply Chains Complete Diversified Multi-Hub Expansion",
            category = NewsCategory.ECONOMICS.name,
            publishedAt = "1 hour ago",
            timestamp = System.currentTimeMillis() - (60 * 60 * 1000),
            readTimeMinutes = 2,
            keyTakeawaysDelimited = "New advanced fabrication plants in Japan, Germany, and the US commence trial wafer production.|||Geographic concentration risk in silicon packaging has declined from 84% to under 55%.|||Automotive and industrial chip lead times have normalized to pre-pandemic 12-week averages.",
            executiveSummary = "The multi-year, multi-billion-dollar global initiative to geographically diversify advanced semiconductor packaging is reaching operational maturity. Major chip manufacturers in Dresden, Kumamoto, and Phoenix have reported first silicon yields that meet commercial quality requirements.\n\nWhile capital expenditure has placed mild pressure on short-term semiconductor margins, international supply chains are significantly more resilient against natural disasters and geopolitical shipping bottlenecks.",
            whyItMatters = "Mitigates future electronics and automotive production delays, shielding consumers from sudden price spikes during global logistics shocks.",
            sourceName = "Global Tech Economics Journal",
            impactLevel = "High Impact",
            tagsDelimited = "Semiconductors|||Supply Chain|||Manufacturing|||Tech"
        ),
        NewsSummary(
            id = "eco_03",
            title = "Emerging Economies Lead Growth Surge via Cross-Border Digital Payment Rails",
            category = NewsCategory.ECONOMICS.name,
            publishedAt = "3 hours ago",
            timestamp = System.currentTimeMillis() - (180 * 60 * 1000),
            readTimeMinutes = 1,
            keyTakeawaysDelimited = "Interlinked national instant payment systems cross $1.8T in cross-border settlements.|||Remittance transaction fees fell from an average of 6.2% to less than 1.4% internationally.|||Small business cross-border export volume grew 32% year-on-year across Southeast Asia and Latin America.",
            executiveSummary = "Interconnected real-time payment networks across emerging markets are proving to be powerful economic growth catalysts. By directly linking central-bank-backed retail settlement layers, cross-border remittances and micro-trade settlements now clear within seconds without traditional correspondent banking friction.\n\nEconomists estimate the transaction cost savings injected over $45 billion directly back into household disposable incomes over the past twelve months.",
            whyItMatters = "Migrant families keep more of their earnings, and independent micro-exporters gain immediate frictionless access to international customers.",
            sourceName = "World Bank Economic Review",
            impactLevel = "Breakthrough",
            tagsDelimited = "Fintech|||Emerging Markets|||Trade|||Payments"
        ),

        // CLIMATE
        NewsSummary(
            id = "clim_01",
            title = "Perovskite-Silicon Tandem Solar Cells Shatter 34% Commercial Efficiency Record",
            category = NewsCategory.CLIMATE.name,
            publishedAt = "45 mins ago",
            timestamp = System.currentTimeMillis() - (45 * 60 * 1000),
            readTimeMinutes = 1,
            keyTakeawaysDelimited = "Next-generation tandem photovoltaic cells achieved 34.2% certified laboratory efficiency.|||Pilot manufacturing lines demonstrate commercial stability exceeding 25-year rooftop standards.|||Levelized cost of solar electricity projected to decline an additional 18% over three years.",
            executiveSummary = "A joint consortium of international materials science laboratories has validated a critical commercial milestone for perovskite-silicon tandem solar cells. By layering specialized mineral crystals atop conventional silicon wafers, the panels capture both blue and red spectral wavelengths, pushing efficiency well beyond silicon's theoretical limit of 29%.\n\nAccelerated aging tests confirmed moisture-resistant encapsulation, addressing the primary historical barrier to mass commercial deployment.",
            whyItMatters = "Rooftops and commercial solar farms will produce up to 30% more clean electricity from the exact same surface area at lower total cost.",
            sourceName = "Nature Energy & CleanGrid Daily",
            impactLevel = "Breakthrough",
            tagsDelimited = "Solar Energy|||Clean Tech|||Renewables|||Innovation"
        ),
        NewsSummary(
            id = "clim_02",
            title = "Global Methane Satellite Constellation Enforces Rapid Industrial Leak Mitigations",
            category = NewsCategory.CLIMATE.name,
            publishedAt = "2 hours ago",
            timestamp = System.currentTimeMillis() - (120 * 60 * 1000),
            readTimeMinutes = 2,
            keyTakeawaysDelimited = "High-precision orbital sensors identify and publicly attribute methane point-source emissions in real time.|||Over 1,400 super-emitter pipeline and flaring leaks sealed within 72 hours of notification.|||Methane intensity from major energy exporters dropped 22% in audited compliance zones.",
            executiveSummary = "Public-access climate satellites equipped with hyperspectral spectrometers are transforming atmospheric regulation. By tracking localized concentrations of methane—a greenhouse gas with over 80 times the warming potency of carbon dioxide in its first two decades—international monitors now pinpoint fugitive emissions to within 10 meters.\n\nEnergy operators worldwide have established rapid-dispatch repair squads to resolve leaks before regulatory penalties or carbon tariff surcharges trigger.",
            whyItMatters = "Plugging methane leaks is the fastest, most cost-effective lever to curb near-term global temperature increases.",
            sourceName = "Atmospheric Science & Policy Bulletin",
            impactLevel = "Policy Shift",
            tagsDelimited = "Methane|||Emissions|||Satellites|||Climate Policy"
        ),
        NewsSummary(
            id = "clim_03",
            title = "Municipal Microgrids and Sodium-Ion Storage Shield Cities from Extreme Heatwaves",
            category = NewsCategory.CLIMATE.name,
            publishedAt = "4 hours ago",
            timestamp = System.currentTimeMillis() - (240 * 60 * 1000),
            readTimeMinutes = 1,
            keyTakeawaysDelimited = "Sodium-ion grid batteries provide non-flammable, lithium-free storage at 40% lower material cost.|||Decentralized urban microgrids maintained uninterrupted power during peak record temperatures.|||Cooling center access guaranteed for vulnerable populations through autonomous backup islanding.",
            executiveSummary = "Cities facing unprecedented seasonal heat waves are increasingly relying on localized electrical microgrids powered by earth-abundant sodium-ion battery arrays. Unlike lithium batteries, sodium-ion chemistry utilizes common salt derivatives, resists thermal runaway in extreme temperatures, and eliminates dependence on cobalt and nickel.\n\nMunicipal utilities in over 80 cities recorded zero blackout incidents despite record-shattering air-conditioning demand.",
            whyItMatters = "Prevents life-threatening grid collapses during peak summer heat while weaning energy storage away from rare earth supply bottlenecks.",
            sourceName = "Urban Resilience Institute",
            impactLevel = "High Impact",
            tagsDelimited = "Grid Storage|||Batteries|||Urban Climate|||Adaptation"
        ),

        // EDUCATION
        NewsSummary(
            id = "edu_01",
            title = "UNESCO Study: Adaptive AI Tutors Narrow Primary Literacy Gaps by 28%",
            category = NewsCategory.EDUCATION.name,
            publishedAt = "35 mins ago",
            timestamp = System.currentTimeMillis() - (35 * 60 * 1000),
            readTimeMinutes = 1,
            keyTakeawaysDelimited = "A 2-year longitudinal study across 45,000 students demonstrated accelerated reading comprehension.|||Adaptive scaffolding allows struggling learners to master phonetics at their individualized pacing.|||Teachers gained an average of 4.5 hours weekly by automating rote diagnostic grading.",
            executiveSummary = "A comprehensive multi-country assessment published by UNESCO highlights the measurable impact of ethical, localized adaptive learning tools in primary classrooms. Rather than replacing human pedagogy, intelligent tutoring systems identify individual phonemic blind spots and generate contextualized reading passages tailored to student interests.\n\nSignificantly, the largest gains occurred among rural students and English language learners who previously lacked one-on-one instructional support.",
            whyItMatters = "Demonstrates how responsible educational technology can democratize high-quality personalized tutoring for underserved communities.",
            sourceName = "UNESCO Global Education Monitoring",
            impactLevel = "Breakthrough",
            tagsDelimited = "EdTech|||Literacy|||Primary Education|||UNESCO"
        ),
        NewsSummary(
            id = "edu_02",
            title = "Universities Adopt Verified Micro-Credentials for Green Economy & AI Careers",
            category = NewsCategory.EDUCATION.name,
            publishedAt = "2 hours ago",
            timestamp = System.currentTimeMillis() - (120 * 60 * 1000),
            readTimeMinutes = 2,
            keyTakeawaysDelimited = "Over 120 global research universities launch stackable modular micro-degrees.|||Students combine traditional theory with industry-verified practical competency portfolios.|||Time-to-employment for certificate holders shortened by 35% compared to non-modular tracks.",
            executiveSummary = "Higher education institutions are undergoing a fundamental structural evolution. To meet surging demand in fields such as clean energy grid engineering, applied machine learning, and ecological restoration, universities are unbundling traditional four-year degrees into accredited, modular credentials.\n\nCorporate hiring councils now accept these cryptographically verified skills transcripts directly, acknowledging hands-on capstone performance alongside academic coursework.",
            whyItMatters = "Learners can upskill without taking on crushing multi-year student debt, aligning education directly with 21st-century job creation.",
            sourceName = "Chronicle of Higher Ed & FutureSkills",
            impactLevel = "Policy Shift",
            tagsDelimited = "Higher Ed|||MicroCredentials|||Workforce|||STEM"
        ),
        NewsSummary(
            id = "edu_03",
            title = "Global STEM Initiative Deploys Solar-Powered Offline Digital Labs to 1.2M Classrooms",
            category = NewsCategory.EDUCATION.name,
            publishedAt = "5 hours ago",
            timestamp = System.currentTimeMillis() - (300 * 60 * 1000),
            readTimeMinutes = 1,
            keyTakeawaysDelimited = "Low-power digital lab units operate completely off-grid with localized educational mirrors.|||Contains interactive science simulations, multilingual open textbooks, and coding environments.|||Female STEM participation in recipient rural districts increased by 41% in year one.",
            executiveSummary = "A global coalition of philanthropic foundations and hardware engineers has completed the first phase of an audacious global education program. The initiative installs self-contained, solar-rechargeable classroom servers in remote areas lacking reliable electrical grids or internet connectivity.\n\nChildren in remote mountainous and island communities can explore simulated chemistry experiments, astronomy models, and open-source coding curriculums on low-cost e-paper tablets.",
            whyItMatters = "Closes the digital divide for millions of young scientists regardless of their village's electrical or broadband infrastructure.",
            sourceName = "Global Education Alliance",
            impactLevel = "High Impact",
            tagsDelimited = "STEM|||Digital Divide|||Rural Schools|||Global South"
        ),

        // WORLD NEWS
        NewsSummary(
            id = "world_01",
            title = "Historic High Seas Treaty Secures Binding Ratification for Ocean Protection",
            category = NewsCategory.WORLD.name,
            publishedAt = "15 mins ago",
            timestamp = System.currentTimeMillis() - (15 * 60 * 1000),
            readTimeMinutes = 1,
            keyTakeawaysDelimited = "60th nation deposits instrument of ratification, formally bringing the landmark accord into force.|||Establishes conservation mandates across international waters covering nearly half of Earth's surface.|||Creates binding environmental impact assessments before deep-sea exploration can proceed.",
            executiveSummary = "After decades of international negotiations, the UN High Seas Biodiversity Treaty has officially entered into legal force. The pact establishes clear governance mechanisms to create Marine Protected Areas (MPAs) in international waters—regions that previously suffered from regulatory ambiguity and overexploitation.\n\nThe treaty also outlines equitable benefit-sharing arrangements for marine genetic resources discovered in deep-ocean ecosystems, safeguarding developing nations' technological equity.",
            whyItMatters = "Protects migratory marine life, stabilizes oceanic carbon sequestration, and establishes unprecedented multilateral ocean governance.",
            sourceName = "United Nations News & Reuters",
            impactLevel = "High Impact",
            tagsDelimited = "Oceans|||United Nations|||Treaties|||Conservation"
        ),
        NewsSummary(
            id = "world_02",
            title = "Cross-Continental Green Hydrogen Corridor Accord Signed in Geneva",
            category = NewsCategory.WORLD.name,
            publishedAt = "1 hour ago",
            timestamp = System.currentTimeMillis() - (60 * 60 * 1000),
            readTimeMinutes = 2,
            keyTakeawaysDelimited = "Trilateral agreement between North African renewable producers and European industrial hubs signed.|||Pipeline network will transport 4 million metric tons of green hydrogen annually by 2032.|||Backed by $14B in blended multilateral infrastructure finance and green bond guarantees.",
            executiveSummary = "Diplomats and infrastructure ministers concluded negotiations on a trans-Mediterranean green energy partnership. The corridor will leverage immense North African solar and wind resources to generate green hydrogen, transporting it via repurposed and newly built pipeline networks to heavy industry hubs across the continent.\n\nThe framework includes stringent local workforce development guarantees and joint sovereign oversight committees to ensure mutual industrial benefit.",
            whyItMatters = "Accelerates the decarbonization of hard-to-abate steel and fertilizer manufacturing while fostering stable intercontinental economic ties.",
            sourceName = "World Energy Diplomatic Wire",
            impactLevel = "Policy Shift",
            tagsDelimited = "Energy Diplomacy|||Green Hydrogen|||Infrastructure|||Trade"
        ),
        NewsSummary(
            id = "world_03",
            title = "World Health Assembly Adopts Instant Early-Warning Pandemic Data Protocol",
            category = NewsCategory.WORLD.name,
            publishedAt = "3 hours ago",
            timestamp = System.currentTimeMillis() - (180 * 60 * 1000),
            readTimeMinutes = 1,
            keyTakeawaysDelimited = "194 member states approve binding 24-hour pathogen sequence notification guidelines.|||Establishes equitable pre-allocation guarantees for diagnostics and therapeutics during emergencies.|||Standardized open genomics platforms will detect novel zoonotic variants months ahead of clinical peaks.",
            executiveSummary = "The World Health Assembly has unanimously adopted an updated global health protocol aimed at eliminating delays in pathogen intelligence sharing. Under the consensus agreement, national laboratory surveillance systems will automatically sequence and share pathogen genomic data through decentralized secure ledgers.\n\nIn exchange, a multilateral supply reserve guarantees that participating developing nations receive immediate, cost-free access to emergency vaccines and therapeutic shipments.",
            whyItMatters = "Replaces geopolitical hoarding with transparent scientific cooperation, dramatically improving humanity's readiness against emerging health threats.",
            sourceName = "World Health Organization & AP",
            impactLevel = "Developing",
            tagsDelimited = "Global Health|||WHO|||Genomics|||Diplomacy"
        )
    )
}

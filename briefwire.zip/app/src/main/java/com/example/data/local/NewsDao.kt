package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.NewsSummary
import kotlinx.coroutines.flow.Flow

@Dao
interface NewsDao {
    @Query("SELECT * FROM news_summaries ORDER BY timestamp DESC")
    fun getAllSummaries(): Flow<List<NewsSummary>>

    @Query("SELECT * FROM news_summaries WHERE category = :category ORDER BY timestamp DESC")
    fun getSummariesByCategory(category: String): Flow<List<NewsSummary>>

    @Query("SELECT * FROM news_summaries WHERE isBookmarked = 1 ORDER BY timestamp DESC")
    fun getBookmarkedSummaries(): Flow<List<NewsSummary>>

    @Query("SELECT * FROM news_summaries WHERE id = :id LIMIT 1")
    fun getSummaryById(id: String): Flow<NewsSummary?>

    @Query("""
        SELECT * FROM news_summaries 
        WHERE title LIKE '%' || :query || '%' 
           OR executiveSummary LIKE '%' || :query || '%' 
           OR keyTakeawaysDelimited LIKE '%' || :query || '%'
           OR tagsDelimited LIKE '%' || :query || '%'
        ORDER BY timestamp DESC
    """)
    fun searchSummaries(query: String): Flow<List<NewsSummary>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(summaries: List<NewsSummary>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(summary: NewsSummary)

    @Query("UPDATE news_summaries SET isBookmarked = :isBookmarked WHERE id = :id")
    suspend fun updateBookmark(id: String, isBookmarked: Boolean)

    @Query("UPDATE news_summaries SET isRead = :isRead WHERE id = :id")
    suspend fun updateReadStatus(id: String, isRead: Boolean)

    @Query("UPDATE news_summaries SET isRead = 1")
    suspend fun markAllAsRead()

    @Query("UPDATE news_summaries SET isRead = 0")
    suspend fun clearReadHistory()

    @Query("SELECT COUNT(*) FROM news_summaries")
    suspend fun getCount(): Int
}

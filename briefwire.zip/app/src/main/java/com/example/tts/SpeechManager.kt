package com.example.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class SpeechManager(context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)

    private val _isReady = MutableStateFlow(false)
    val isReady: StateFlow<Boolean> = _isReady.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentStoryId = MutableStateFlow<String?>(null)
    val currentStoryId: StateFlow<String?> = _currentStoryId.asStateFlow()

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
            tts?.setSpeechRate(1.0f)
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isPlaying.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isPlaying.value = false
                    _currentStoryId.value = null
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isPlaying.value = false
                    _currentStoryId.value = null
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    _isPlaying.value = false
                    _currentStoryId.value = null
                }
            })
            _isReady.value = true
        }
    }

    fun speakStory(storyId: String, title: String, takeaways: List<String>, summary: String) {
        if (!_isReady.value) return

        if (_isPlaying.value && _currentStoryId.value == storyId) {
            stop()
            return
        }

        stop()
        _currentStoryId.value = storyId
        _isPlaying.value = true

        val speechBuilder = StringBuilder()
        speechBuilder.append(title).append(". ")
        if (takeaways.isNotEmpty()) {
            speechBuilder.append("Key takeaways. ")
            takeaways.forEachIndexed { index, takeaway ->
                speechBuilder.append("Point ").append(index + 1).append(": ").append(takeaway).append(". ")
            }
        }
        speechBuilder.append("Summary: ").append(summary)

        val textToSpeak = speechBuilder.toString()
        tts?.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, null, storyId)
    }

    fun stop() {
        tts?.stop()
        _isPlaying.value = false
        _currentStoryId.value = null
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}

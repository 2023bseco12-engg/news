package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.NewsCategory
import com.example.data.model.NewsSummary
import com.example.data.remote.GeminiApiClient
import com.example.data.repository.NewsRepository
import com.example.tts.SpeechManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

enum class FilterType(val label: String) {
    ALL("All Stories"),
    UNREAD("Unread"),
    BOOKMARKS("Saved")
}

sealed class AiExplainerUiState {
    object Idle : AiExplainerUiState()
    object Loading : AiExplainerUiState()
    data class Success(val title: String, val content: String, val promptLabel: String) : AiExplainerUiState()
    data class Error(val message: String) : AiExplainerUiState()
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: NewsRepository
    val speechManager: SpeechManager = SpeechManager(application)

    init {
        val database = AppDatabase.getDatabase(application)
        repository = NewsRepository(database.newsDao())
        viewModelScope.launch {
            repository.ensureInitialDataLoaded()
        }
    }

    private val _selectedCategory = MutableStateFlow(NewsCategory.ALL)
    val selectedCategory: StateFlow<NewsCategory> = _selectedCategory.asStateFlow()

    private val _filterType = MutableStateFlow(FilterType.ALL)
    val filterType: StateFlow<FilterType> = _filterType.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedStory = MutableStateFlow<NewsSummary?>(null)
    val selectedStory: StateFlow<NewsSummary?> = _selectedStory.asStateFlow()

    private val _isDailyBriefingOpen = MutableStateFlow(false)
    val isDailyBriefingOpen: StateFlow<Boolean> = _isDailyBriefingOpen.asStateFlow()

    private val _aiExplainerState = MutableStateFlow<AiExplainerUiState>(AiExplainerUiState.Idle)
    val aiExplainerState: StateFlow<AiExplainerUiState> = _aiExplainerState.asStateFlow()

    private val allStories = repository.getAllSummaries()

    val filteredStories: StateFlow<List<NewsSummary>> = combine(
        allStories,
        _selectedCategory,
        _filterType,
        _searchQuery
    ) { stories, category, filter, query ->
        stories.filter { story ->
            val matchesCategory = (category == NewsCategory.ALL || story.category == category.name)
            val matchesFilter = when (filter) {
                FilterType.ALL -> true
                FilterType.UNREAD -> !story.isRead
                FilterType.BOOKMARKS -> story.isBookmarked
            }
            val matchesQuery = if (query.isBlank()) {
                true
            } else {
                val q = query.trim().lowercase()
                story.title.lowercase().contains(q) ||
                        story.executiveSummary.lowercase().contains(q) ||
                        story.tags.any { it.lowercase().contains(q) } ||
                        story.sourceName.lowercase().contains(q)
            }
            matchesCategory && matchesFilter && matchesQuery
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val topDailyHighlights: StateFlow<List<NewsSummary>> = allStories.combine(_selectedCategory) { stories, _ ->
        // Pick top 1 from each category for the 60-Second Daily Briefing
        val categories = listOf(
            NewsCategory.ECONOMICS.name,
            NewsCategory.CLIMATE.name,
            NewsCategory.EDUCATION.name,
            NewsCategory.WORLD.name
        )
        categories.mapNotNull { cat ->
            stories.firstOrNull { it.category == cat }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun selectCategory(category: NewsCategory) {
        _selectedCategory.value = category
    }

    fun selectFilter(filter: FilterType) {
        _filterType.value = filter
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun openStory(story: NewsSummary) {
        _selectedStory.value = story
        markAsRead(story, true)
    }

    fun closeStory() {
        _selectedStory.value = null
    }

    fun openDailyBriefing() {
        _isDailyBriefingOpen.value = true
    }

    fun closeDailyBriefing() {
        _isDailyBriefingOpen.value = false
    }

    fun toggleBookmark(story: NewsSummary) {
        viewModelScope.launch {
            repository.toggleBookmark(story.id, story.isBookmarked)
            // If currently viewing details, update local object
            if (_selectedStory.value?.id == story.id) {
                _selectedStory.value = _selectedStory.value?.copy(isBookmarked = !story.isBookmarked)
            }
        }
    }

    fun markAsRead(story: NewsSummary, isRead: Boolean) {
        viewModelScope.launch {
            repository.markAsRead(story.id, isRead)
            if (_selectedStory.value?.id == story.id) {
                _selectedStory.value = _selectedStory.value?.copy(isRead = isRead)
            }
        }
    }

    fun markAllAsRead() {
        viewModelScope.launch {
            repository.markAllAsRead()
        }
    }

    fun toggleAudio(story: NewsSummary) {
        if (speechManager.isPlaying.value && speechManager.currentStoryId.value == story.id) {
            speechManager.stop()
        } else {
            speechManager.speakStory(
                storyId = story.id,
                title = story.title,
                takeaways = story.takeaways,
                summary = story.executiveSummary
            )
        }
    }

    fun stopAudio() {
        speechManager.stop()
    }

    fun requestAiInsight(story: NewsSummary, promptType: String) {
        viewModelScope.launch {
            _aiExplainerState.value = AiExplainerUiState.Loading

            val prompt = when (promptType) {
                "simplified" -> """
                    You are an expert news analyst. Given this news summary:
                    Title: "${story.title}"
                    Category: ${story.category}
                    Executive Summary: "${story.executiveSummary}"
                    
                    Explain this story simply in 3 punchy, easy-to-understand bullet points suitable for a 12-year-old or general reader. Keep it clear, concise, and jargon-free.
                """.trimIndent()
                "why_it_matters" -> """
                    You are a global affairs and economics analyst. Given this news story:
                    Title: "${story.title}"
                    Category: ${story.category}
                    Summary: "${story.executiveSummary}"
                    
                    Give 2 practical reasons why this matters to everyday citizens, households, or future careers over the next 1-3 years.
                """.trimIndent()
                "future_outlook" -> """
                    You are a strategic forecaster. Given this news summary:
                    Title: "${story.title}"
                    Category: ${story.category}
                    Summary: "${story.executiveSummary}"
                    
                    Provide a concise forward-looking scenario: What key milestone or regulatory/market event should we watch for next? (Max 2 short paragraphs).
                """.trimIndent()
                else -> """
                    Provide a brief insightful analysis of the following story:
                    Title: "${story.title}"
                    Category: ${story.category}
                    Summary: "${story.executiveSummary}"
                """.trimIndent()
            }

            val result = GeminiApiClient.askGemini(prompt)
            result.fold(
                onSuccess = { responseText ->
                    val label = when (promptType) {
                        "simplified" -> "Simplified Explanation"
                        "why_it_matters" -> "Why It Matters To You"
                        "future_outlook" -> "Forward Outlook"
                        else -> "AI Analysis"
                    }
                    _aiExplainerState.value = AiExplainerUiState.Success(
                        title = story.title,
                        content = responseText,
                        promptLabel = label
                    )
                },
                onFailure = { err ->
                    // Fallback to high-quality built-in editorial commentary if API key not set
                    val fallbackContent = when (promptType) {
                        "simplified" -> "• Core takeaway: ${story.takeaways.getOrNull(0) ?: story.title}\n• Key driver: ${story.whyItMatters}\n• Practical impact: Global standards and markets are actively adjusting."
                        "why_it_matters" -> "1. Direct impact: ${story.whyItMatters}\n2. Systemic effect: Shifting international policies in ${story.category.lowercase()} influence long-term costs, consumer standards, and job markets."
                        "future_outlook" -> "Over the next 6-12 months, expect subsequent monitoring reports and pilot implementations to validate operational milestones. Regulatory compliance bodies will hold follow-up sessions."
                        else -> story.executiveSummary
                    }
                    val label = when (promptType) {
                        "simplified" -> "Simplified Explanation (Editorial Brief)"
                        "why_it_matters" -> "Why It Matters (Editorial Brief)"
                        "future_outlook" -> "Outlook (Editorial Brief)"
                        else -> "Editorial Analysis"
                    }
                    _aiExplainerState.value = AiExplainerUiState.Success(
                        title = story.title,
                        content = fallbackContent,
                        promptLabel = label
                    )
                }
            )
        }
    }

    fun dismissAiExplainer() {
        _aiExplainerState.value = AiExplainerUiState.Idle
    }

    override fun onCleared() {
        super.onCleared()
        speechManager.shutdown()
    }
}

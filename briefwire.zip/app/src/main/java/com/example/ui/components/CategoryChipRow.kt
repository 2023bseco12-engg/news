package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.Eco
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NewsCategory
import com.example.ui.theme.CategoryClimateDark
import com.example.ui.theme.CategoryEconomicsDark
import com.example.ui.theme.CategoryEducationDark
import com.example.ui.theme.CategoryWorldDark

@Composable
fun CategoryChipRow(
    selectedCategory: NewsCategory,
    onCategorySelected: (NewsCategory) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NewsCategory.values().forEach { category ->
            val isSelected = category == selectedCategory
            CategoryChip(
                category = category,
                isSelected = isSelected,
                onClick = { onCategorySelected(category) }
            )
        }
    }
}

@Composable
fun CategoryChip(
    category: NewsCategory,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val categoryColor = getCategoryColor(category)
    val icon = getCategoryIcon(category)

    val backgroundColor = if (isSelected) {
        categoryColor.copy(alpha = 0.22f)
    } else {
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
    }

    val contentColor = if (isSelected) {
        categoryColor
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant
    }

    Box(
        modifier = Modifier
            .testTag("category_chip_${category.name.lowercase()}")
            .clip(RoundedCornerShape(20.dp))
            .background(backgroundColor)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = category.title,
                tint = contentColor,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = category.title,
                color = contentColor,
                fontSize = 13.sp,
                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium
            )
        }
    }
}

fun getCategoryIcon(category: NewsCategory): ImageVector = when (category) {
    NewsCategory.ALL -> Icons.Default.Newspaper
    NewsCategory.ECONOMICS -> Icons.AutoMirrored.Filled.TrendingUp
    NewsCategory.CLIMATE -> Icons.Default.Eco
    NewsCategory.EDUCATION -> Icons.Default.School
    NewsCategory.WORLD -> Icons.Default.Public
}

fun getCategoryColor(category: NewsCategory): Color = when (category) {
    NewsCategory.ALL -> Color(0xFF38BDF8)
    NewsCategory.ECONOMICS -> CategoryEconomicsDark
    NewsCategory.CLIMATE -> CategoryClimateDark
    NewsCategory.EDUCATION -> CategoryEducationDark
    NewsCategory.WORLD -> CategoryWorldDark
}

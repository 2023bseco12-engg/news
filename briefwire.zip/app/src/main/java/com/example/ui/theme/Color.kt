package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary theme colors
val PrimaryBlue = Color(0xFF0284C7)
val PrimaryLightBlue = Color(0xFF38BDF8)
val DarkNavyBg = Color(0xFF0B1120)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF334155)
val LightBg = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)

// Category Semantic Colors
val CategoryEconomics = Color(0xFF0284C7) // Sky Blue
val CategoryEconomicsDark = Color(0xFF38BDF8)

val CategoryClimate = Color(0xFF059669) // Emerald
val CategoryClimateDark = Color(0xFF34D399)

val CategoryEducation = Color(0xFF4F46E5) // Indigo
val CategoryEducationDark = Color(0xFF818CF8)

val CategoryWorld = Color(0xFFD97706) // Amber
val CategoryWorldDark = Color(0xFFFBBF24)

// Neutral Accents
val TextPrimaryDark = Color(0xFFF1F5F9)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF64748B)

val CardBorderDark = Color(0xFF334155)
val CardBorderLight = Color(0xFFE2E8F0)
